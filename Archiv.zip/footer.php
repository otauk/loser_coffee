<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package losercoffee
 */
?>

</div>

<div class="footer_bg">
	<div class="row footer">
		<div class="col-md-2 footerBorder noshow">
			<h2>Allgemein</h2>
			<a href="#">Über uns</a><br/>
			<a href="#">Röstmaschine</a><br/>
			<a href="#">Wissensdurst</a><br/>
			<a href="#">Kontakt</a><br/>
			<a href="#">Impressum</a><br/>
			<a href="#">Datenschutz</a><br/>
		</div>
		<div class="col-md-2 footerBorder noshow">
			<h2>Shop</h2>
			<a href="#">Produkte</a><br/>
			<a href="#">Versandkosten</a><br/>
			<a href="#">Bezahlarten</a><br/>
			<a href="#">AGB</a><br/>
		</div>
		<div class="col-md-2 col-xs-3">
			<h2>Kontakt</h2>
			Loser Coffee<br/>
			Strasse<br/>
			33100 Paderborn<br/>
			05251 | 12 23 45<br/>
			info@loser-coffee.de
		</div>
		<div class="col-md-2 noshow">

		</div>
		<div class="col-md-2 noshow">
			<div class="footerLogo"></div>
		</div>
		<div class="col-md-2 col-xs-3">
			<div class="footerBanner">

					<h2>Mein<br/> Warenkorb</h2>
					<div class="icon-warenkorb">
					</div>
					<a class="cart-contents" href="<?php echo WC()->cart->get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>"><?php echo sprintf (_n( '%d', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?> Artikel</a>
					<hr/>
					<div class="icon-geld">
					</div>
					<?php echo WC()->cart->get_cart_total(); ?>
					<hr/>
					<h2 class="white">
						<?php global $woocommerce; ?>
						<a href="<?php echo $woocommerce->cart->get_checkout_url();?>">
						>> Kasse
						</a></h2>

			</div>

		</div>
	</div>


</div><!-- .wrapper -->
</div>

<?php wp_footer(); ?>

</body>
</html>
